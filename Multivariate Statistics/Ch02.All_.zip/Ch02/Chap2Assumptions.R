#  Chapter 2 Issues and Assumptions

help.search("normality")

install.packages("mvnormtest")		# Install mvnormtest package 
library(mvnormtest)				# Load package in library
data(attitude)				# Load data set

library()			# Check list of packages
data()			# Check list of data sets available in R
attach(attitude)		# Attach data file so you can use variable names
head (attitude, n=10)		# Print first 10 lines of data set

mydata = t(attitude)			# Transpose data set
mshapiro.test(mydata)		# Run function on transposed data set

install.packages("normtest")	# Install R normtest package
library(normtest)			# Load package in library
jb.norm.test(attitude)		# Run jb.norm.test function

install.packages("normwhn.test")		# Install R normwhn.test package
library(normwhn.test)			 	# Load package in library
normality.test1(attitude)			# Run normality.test1 function

install.packages("nortest")		# Install R nortest package
library(nortest)			# Load package in library
attach(attitude)  			 # Attach data set to use of variable names 


ad.test(rating)		# Anderson-Darling
cvm.test(rating)		# Cramer-von Mises
lillie.test(rating)		# Kolmogorov-Smirnov
pearson.test(rating)		# Pearson chi-square
sf.test(rating)		# Shapiro-Francia


mycor = cor(attitude)      # Create square correlation matrix
det(mycor)		        # Determinant of correlation matrix


mycov = cov(attitude)	 # Create a square variance-covariance matrix
det(mycov)		        	 # Determinant of variance-covariance matrix


mymatrix = cov2cor(mycov)	# Convert covariance matrix to correlation matrix
mymatrix				# Print out correlation matrix

mycor	#  prints correlation matrix from attitude data set

group = rep(c("boy","girl"),c(15,15))          # Create group variable (15 boys, 15 girls)
newdata= data.frame(attitude,group)           # Merge attitude file with group variable
head(newdata,n=10)                                     # Print out the first 10 data lines


options (scipen = 999) 	# Stops scientific notation output 
boys = newdata[1:15,]	# Select only boys from data set
boycov = cov(boys[,-8])	# Create covariance matrix
det(boycov)			# Compute determinant of matrix

girls = newdata[16:30,]	# Select only girls from data set
girlcov = cov(girls[,-8])	# Create covariance matrix
det(girlcov)			# Compute determinant of matrix

install.packages("psych")			# Install R psych package
library(psych)				# Load package in library
describeBy(newdata, group = group)	# Run describeBy function

cov.list = lapply(unique(newdata$group),function(x)cov(newdata[newdata$group==x,-8]))	

cov.list[1]
cov.list[2]

boys = newdata[1:15,]    		# Select only boys from data set
boycov = cov(boys[,-8])		# Compute variance-covariance matrix  
boycor = cov2cor(boycov)		# Convert covariance matrix to correlation matrix
boycor				# Print boys correlation matrix

girls = newdata[16:30,]		# Select only girls from data set
girlcov = cov(girls[,-8])		# Compute variance-covariance matrix
girlcor = cov2cor(girlcov)		# Convert covariance matrix to correlation matrix
girlcor				# Print girls correlation matrix

install.packages("biotools")		# Install R biotools package
library(biotools)			# Load package in library
data(iris)				# Load data set
factor(iris[,5])			# Select variables for matrix, minus grouping variable
boxM(iris[, -5], iris[, 5])		# Run function with variables and group variable specified

install.packages("biotools")		# Install R biotools package
library(biotools)			# Load package in library
data(newdata)			# Load data set
factor(group) 			# Declare grouping variable a factor
boxM(newdata[,-8],newdata[,8])	# Run boxM function

# Eigenvalues of correlation matrix should equal total variance
# (sum of diagonal values in correlation matrix)
# This is also equal to the number of variables

mycor
eigen(mycor)


